/*
 * @file spi_config.h
 * @brief SPI Configuration for AVR32DA28
 */

#ifndef SPI_CONFIG_H
#define SPI_CONFIG_H

#include <avr/io.h>

/* ============================================ SPI PORT CONFIGURATION ============================================ */

/* SPI0 on Port A (AVR32DA28) */
#define SPI_PORT        PORTA           /* SPI port (VPORT struct) */
#define MOSI_BIT        4               /* PA4 - MOSI */
#define MISO_BIT        5               /* PA5 - MISO */
#define SCK_BIT         6               /* PA6 - SCK */
#define SS_BIT          7               /* PA7 - SS (Chip Select) */

/* Optional: Alternate SS pin if using different port for chip select */
/* #define ALT_SS_PORT     PORTB */
/* #define ALT_SS_BIT      0 */

#endif /* SPI_CONFIG_H */
