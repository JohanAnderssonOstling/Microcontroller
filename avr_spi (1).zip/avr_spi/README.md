# AVR SPI Driver for AVR32DA28

## Overview

This is a lightweight, polled SPI master driver for AVR microcontrollers, optimized for AVR32DA28.

## Files

- `avr_spi.h` - Header with SPI function prototypes
- `avr_spi.c` - Implementation
- `spi_config.h` - Configuration for AVR32DA28

## Configuration

### Default: AVR32DA28 SPI0 on Port A

```c
MOSI: PA4
MISO: PA5
SCK:  PA6
SS:   PA7
```

To change pins, edit `spi_config.h`:

```c
#define SPI_PORT    PORTA
#define SPI_DDR     DDRA
#define MOSI_BIT    4
#define MISO_BIT    5
#define SCK_BIT     6
#define SS_BIT      7
```

## API Functions

### Initialize SPI

```c
void SPI_Init(SPI_MODE_t mode, SPI_CLKDIV_t clk_div);
```

**Parameters:**
- `mode`: `SPI_MODE0`, `SPI_MODE1`, `SPI_MODE2`, `SPI_MODE3`
- `clk_div`: `SPI_CLKDIV_2`, `SPI_CLKDIV_4`, `SPI_CLKDIV_8`, `SPI_CLKDIV_16`, `SPI_CLKDIV_32`, `SPI_CLKDIV_64`, `SPI_CLKDIV_128`

**Example:**
```c
SPI_Init(SPI_MODE0, SPI_CLKDIV_16);
```

### Transmit and Receive Single Byte

```c
uint8_t SPI_TxRx(uint8_t data);
```

Sends one byte and returns received byte.

### Transmit Buffer

```c
void SPI_TxBuf(const uint8_t *buf, uint16_t length);
```

Transmits a buffer (receives are discarded).

### Receive Buffer

```c
void SPI_RxBuf(uint8_t *buf, uint16_t length);
```

Receives a buffer (transmits 0x00 bytes).

### Transmit and Receive Buffer

```c
void SPI_TransmitReceive(const uint8_t *tx_buf, uint8_t *rx_buf, uint16_t length);
```

Transmits and receives simultaneously.

## Usage Example

```c
#include "avr_spi.h"

int main(void)
{
    /* Initialize SPI: MODE0, clock divider 16 */
    SPI_Init(SPI_MODE0, SPI_CLKDIV_16);

    /* Transmit and receive */
    uint8_t tx_data[3] = {0xAA, 0xBB, 0xCC};
    uint8_t rx_data[3] = {0};

    SPI_TransmitReceive(tx_data, rx_data, 3);

    return 0;
}
```

## Notes

- This driver uses **polling** (not interrupts)
- **NOT thread-safe** - disable interrupts if using SPI in ISR
- Handles SS (chip select) automatically in SS_HIGH()/SS_LOW() macros
- Blocking operation - waits for SPI completion

## For nRF24L01 Users

This driver is used by the nRF24L01 library. Configuration is handled automatically:

```c
#include "nrf24l01.h"
#include "avr_spi.h"

int main(void)
{
    SPI_Init(SPI_MODE0, SPI_CLKDIV_16);
    NRF24L01_GPIO_Init();
    // ... rest of nRF24L01 code
}
```
