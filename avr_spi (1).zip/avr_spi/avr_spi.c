/*************************************************
 *
 *	spi.c
 *
 *  Polled SPI driver for AVR-Dx series
 *
 ************************************************/

#include <avr/io.h>
#include "avr_spi.h"

/* Initialize the SPI interface in Master mode with given SPI mode and clock rate division */
void SPI_Init(SPI_MODE_t mode, SPI_CLKDIV_t clk_div)
{
	/* Set MOSI, SCK, SS as output */
	SPI_PORT.DIRSET = (1 << MOSI_BIT) | (1 << SCK_BIT) | (1 << SS_BIT);
	/* MISO as input (default, but be explicit) */
	SPI_PORT.DIRCLR = (1 << MISO_BIT);

#ifdef ALT_SS_PORT
	/* Initialize alternate pin to be used as SS */
	ALT_SS_PORT.DIRSET = (1 << ALT_SS_BIT);
#endif

	/* Slave Select pin is initially HIGH */
	SS_HIGH();

	/* SPI mode: MODE bits map to SPI0.CTRLB MODE field */
	SPI0.CTRLB = (mode << SPI_MODE_gp);

	/* Enable SPI, master mode, MSB first, given prescaler */
	SPI0.CTRLA = SPI_ENABLE_bm | SPI_MASTER_bm | clk_div;
}


uint8_t SPI_TxRx(uint8_t data)
{
	/* Start transmission */
	SPI0.DATA = data;

	/* Wait for transfer complete */
	while (!(SPI0.INTFLAGS & SPI_IF_bm))
		;

	return SPI0.DATA;
}


void SPI_TxBuf(const uint8_t *buf, uint16_t length)
{
	while (length--)
	{
		SPI_TxRx(*buf++);
	}
}

void SPI_RxBuf(uint8_t *buf, uint16_t length)
{
	while (length--)
	{
		*buf++ = SPI_TxRx(0x00);
	}
}


void SPI_TransmitReceive(const uint8_t *tx_buf, uint8_t *rx_buf, uint16_t length)
{
	while (length--)
	{
		*rx_buf++ = SPI_TxRx(*tx_buf++);
	}
}
