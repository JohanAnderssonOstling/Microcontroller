/*****************************************
 *
 * 	spi.h
 *
 *  Polled SPI driver for AVR-Dx series
 *
 ************************************************/

#include <stdint.h>
#include "spi_config.h"


typedef enum spi_mode
{
	SPI_MODE0,
	SPI_MODE1,
	SPI_MODE2,
	SPI_MODE3
} SPI_MODE_t;


typedef enum spi_clk_div
{
	SPI_CLKDIV_4   = SPI_PRESC_DIV4_gc,
	SPI_CLKDIV_16  = SPI_PRESC_DIV16_gc,
	SPI_CLKDIV_64  = SPI_PRESC_DIV64_gc,
	SPI_CLKDIV_128 = SPI_PRESC_DIV128_gc
} SPI_CLKDIV_t;


#ifndef ALT_SS_PORT
	#define SS_HIGH()		(SPI_PORT.OUTSET = (1 << SS_BIT))
	#define SS_LOW()		(SPI_PORT.OUTCLR = (1 << SS_BIT))
#else
	#define SS_HIGH()		(ALT_SS_PORT.OUTSET = (1 << ALT_SS_BIT))
	#define SS_LOW()		(ALT_SS_PORT.OUTCLR = (1 << ALT_SS_BIT))
#endif


/* Prototypes */

void SPI_Init(SPI_MODE_t mode, SPI_CLKDIV_t clk_div);
uint8_t SPI_TxRx(uint8_t data);
void SPI_TxBuf(const uint8_t *buf, uint16_t length);
void SPI_RxBuf(uint8_t *buf, uint16_t length);
void SPI_TransmitReceive(const uint8_t *tx_buf, uint8_t *rx_buf, uint16_t length);
