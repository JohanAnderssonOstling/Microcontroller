#include <avr/io.h>
#include <util/delay.h>
#include <stdbool.h>
#include <stdio.h>
#include "uart.h"

#define CE_HIGH()   PORTA.OUTSET = PIN7_bm
#define CE_LOW()    PORTA.OUTCLR = PIN7_bm
#define CSN_HIGH()  PORTA.OUTSET = PIN6_bm
#define CSN_LOW()   PORTA.OUTCLR = PIN6_bm

/* ---------------- SPI ---------------- */

void spi_init(void)
{
    PORTA.DIRSET = PIN1_bm | PIN2_bm | PIN6_bm | PIN7_bm;
    PORTA.DIRCLR = PIN3_bm;

    SPI0.CTRLA = SPI_ENABLE_bm |
                 SPI_MASTER_bm |
                 SPI_PRESC_DIV4_gc;

    SPI0.CTRLB = SPI_SSD_bm;

    CSN_HIGH();
    CE_LOW();
}

uint8_t spi_transfer(uint8_t data)
{
    SPI0.DATA = data;
    while (!(SPI0.INTFLAGS & SPI_IF_bm));
    return SPI0.DATA;
}


void nrf_write_reg(uint8_t reg, uint8_t value)
{
    CSN_LOW();
    spi_transfer(0x20 | reg);
    spi_transfer(value);
    CSN_HIGH();
}

uint8_t nrf_read_reg(uint8_t reg)
{
    uint8_t value;
    CSN_LOW();
    spi_transfer(reg);
    value = spi_transfer(0xFF);
    CSN_HIGH();
    return value;
}

void nrf_write_buf(uint8_t cmd, uint8_t *buf, uint8_t len)
{
    CSN_LOW();
    spi_transfer(cmd);
    for (uint8_t i = 0; i < len; i++)
        spi_transfer(buf[i]);
    CSN_HIGH();
}

void nrf_read_buf(uint8_t cmd, uint8_t *buf, uint8_t len)
{
    CSN_LOW();
    spi_transfer(cmd);
    for (uint8_t i = 0; i < len; i++)
        buf[i] = spi_transfer(0xFF);
    CSN_HIGH();
}

void nrf_flush_tx(void)
{
    CSN_LOW();
    spi_transfer(0xE1);
    CSN_HIGH();
}

void nrf_flush_rx(void)
{
    CSN_LOW();
    spi_transfer(0xE2);
    CSN_HIGH();
}

void nrf_clear_irqs(void)
{
    nrf_write_reg(0x07, (1<<6)|(1<<5)|(1<<4));
}

/* ---------------- DEBUG HELPERS ---------------- */

void nrf_dump_registers(void)
{
    printf("---- NRF REG DUMP ----\n");
    printf("CONFIG:      0x%02X\n", nrf_read_reg(0x00));
    printf("EN_AA:       0x%02X\n", nrf_read_reg(0x01));
    printf("EN_RXADDR:   0x%02X\n", nrf_read_reg(0x02));
    printf("RF_CH:       0x%02X\n", nrf_read_reg(0x05));
    printf("RF_SETUP:    0x%02X\n", nrf_read_reg(0x06));
    printf("STATUS:      0x%02X\n", nrf_read_reg(0x07));
    printf("FIFO_STATUS: 0x%02X\n", nrf_read_reg(0x17));
    printf("-----------------------\n");
}

/* ---------------- NRF INIT ---------------- */

void nrf_init_common(void)
{
    CE_LOW();
    _delay_ms(5);

    nrf_write_reg(0x00, 0x0C);
    nrf_write_reg(0x01, 0x00);
    nrf_write_reg(0x02, 0x01);
    nrf_write_reg(0x03, 0x03);
    nrf_write_reg(0x04, 0x00);
    nrf_write_reg(0x05, 76);
    nrf_write_reg(0x06, 0x07);

    uint8_t addr[5] = {0xE7,0xE7,0xE7,0xE7,0xE7};
    nrf_write_buf(0x30, addr, 5);
    nrf_write_buf(0x2A, addr, 5);
    nrf_write_reg(0x11, 32);

    nrf_clear_irqs();
    nrf_flush_tx();
    nrf_flush_rx();
}

/* ---------------- MODE ---------------- */

void nrf_set_rx_mode(void)
{
    CE_LOW();
    nrf_write_reg(0x00, 0x0F);
    _delay_ms(2);
    CE_HIGH();
    printf("Entered RX mode\n");
}

void nrf_set_tx_mode(void)
{
    CE_LOW();
    nrf_write_reg(0x00, 0x0E);
    _delay_ms(2);
    printf("Entered TX mode\n");
}

/* ---------------- SEND ---------------- */

void nrf_send(uint8_t *data, uint8_t len)
{
    printf("\n=== TX START ===\n");

    nrf_set_tx_mode();
    nrf_flush_tx();
    nrf_clear_irqs();

    printf("STATUS before TX: 0x%02X\n", nrf_read_reg(0x07));

    nrf_write_buf(0xA0, data, len);

    CE_HIGH();
    _delay_us(15);
    CE_LOW();

    while (!(nrf_read_reg(0x07) & ((1<<5)|(1<<4))));

    uint8_t status = nrf_read_reg(0x07);
    printf("STATUS after TX: 0x%02X\n", status);

    if (status & (1<<5))
        printf("TX_DS set (Transmit success)\n");

    if (status & (1<<4))
    {
        printf("MAX_RT set (Transmit failed)\n");
        nrf_flush_tx();
    }

    nrf_clear_irqs();

    printf("FIFO_STATUS: 0x%02X\n", nrf_read_reg(0x17));
    printf("=== TX END ===\n");

    nrf_set_rx_mode();
}

/* ---------------- RECEIVE ---------------- */

bool nrf_available(void)
{
    uint8_t status = nrf_read_reg(0x07);
    if (status & (1<<6))
    {
        printf("RX_DR set\n");
        return true;
    }
    return false;
}

void nrf_read(uint8_t *buf)
{
    printf("\n--- RX START ---\n");

    nrf_read_buf(0x61, buf, 32);

    printf("Raw Data (hex): ");
    for (uint8_t i=0;i<32;i++)
        printf("%02X ", buf[i]);

    printf("\nASCII: ");
    for (uint8_t i=0;i<32;i++)
    {
        if (buf[i] >= 32 && buf[i] <= 126)
            printf("%c", buf[i]);
    }

    printf("\n--- RX END ---\n");

    nrf_clear_irqs();
    nrf_flush_rx();
}

/* ---------------- MAIN ---------------- */

int main(void)
{
    spi_init();
    USART0_init();
    stdout = &USART_stream;

    printf("\nNRF DEBUG START\n");

    nrf_init_common();
    nrf_dump_registers();

    nrf_set_rx_mode();

    uint8_t txmsg[] = "HELLO";
    uint8_t rxbuf[32];

    while (1)
    {
        if (nrf_available())
            nrf_read(rxbuf);

        nrf_send(txmsg, 5);

        _delay_ms(1000);
    }
}