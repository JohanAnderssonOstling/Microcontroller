#define F_CPU 4000000UL
#define BAUD_RATE 9600

// Calculate Baud Register
#define USART0_BAUD_VAL ((float)(4.0 * F_CPU / (BAUD_RATE)) + 0.5)

#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>

void USART0_init(void) {
    PORTF.DIR |= PIN0_bm;       // TX Output
    PORTF.DIR &= ~PIN1_bm;      // RX Input
    USART2.BAUD = (uint16_t)USART0_BAUD_VAL;
    USART2.CTRLB |= USART_TXEN_bm | USART_RXEN_bm;
      USART2.CTRLC = USART_CMODE_ASYNCHRONOUS_gc | USART_PMODE_DISABLED_gc | USART_SBMODE_1BIT_gc | USART_CHSIZE_8BIT_gc;

}


void USART0_sendChar(const char c) {
    while (!(USART2.STATUS & USART_DREIF_bm)) {}
    USART2.TXDATAL = c;
}

int USART0_printChar(const char c, FILE *stream) {
    USART0_sendChar(c);
    return 0;
}

FILE USART_stream = FDEV_SETUP_STREAM(USART0_printChar, NULL, _FDEV_SETUP_WRITE);